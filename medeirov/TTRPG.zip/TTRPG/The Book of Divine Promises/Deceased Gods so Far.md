
#### Greater Deities:

1. **Ao** - Overgod
2. **Mystra** - Goddess of Magic
3. **Torm** - God of Courage and Self-Sacrifice
4. **Tyr** - God of Justice
5. ~~**Bane** - God of Tyranny~~
6. **Chauntea** - Goddess of Agriculture
7. **Kelemvor** - God of the Dead
8. **Lathander** - God of Birth and Renewal
9. **Lolth** - Goddess of Spiders and the Drow
10. **Selûne** - Goddess of the Moon
11. ~~**Heliod** - God of the Sun~~
12. ~~**Raven Queen** - God of Shadowfell and Ravens?~~

#### Intermediate Deities:

1. **Corellon Larethian** - God of Elves
2. **Garl Glittergold** - God of Gnomes
3. **Gruumsh** - God of Orcs
4. **Moradin** - God of Dwarves
5. **Sune** - Goddess of Love and Beauty
6. **Tempus** - God of War
7. **Tymora** - Goddess of Good Fortune
8. **Umberlee** - Goddess of the Sea

#### Lesser Deities:

1. ~~**Auril** - Goddess of Winter~~
2. **Cyric** - God of Lies
3. **Eldath** - Goddess of Peace
4. **Gond** - God of Craft
5. **Ilmater** - God of Endurance
6. **Mielikki** - Goddess of Forests
7. **Oghma** - God of Knowledge
8. ~~**Shar** - Goddess of Darkness and Loss~~
9. ~~**Silvanus** - God of Wild Nature~~
10. ~~God of Snowfall~~
#### The Sovereign Host:

1. **Arawai** - Goddess of Agriculture
2. **Aureon** - God of Law and Knowledge
3. **Balinor** - God of Beasts and the Hunt
4. **Boldrei** - Goddess of Community and Home
5. **Dol Arrah** - Goddess of Honor and Sacrifice
6. **Dol Dorn** - God of Strength at Arms
7. **Kol Korran** - God of Trade and Wealth
8. **Olladra** - Goddess of Good Fortune
9. **Onatar** - God of Artifice and the Forge

#### The Dark Six:

1. **The Devourer** - God of Nature's Wrath
2. **The Fury** - Goddess of Passion and Revenge
3. **The Keeper** - God of Death and Decay
4. **The Mockery** - God of Betrayal and Bloodshed
5. **The Shadow** - God of Ambition and Dark Magic
6. **The Traveler** - God of Chaos and Change

#### Other Deities and Forces:

1. **The Silver Flame** - Divine force of protection and good
2. **The Blood of Vol** - Cult that worships the Divinity Within
3. **The Path of Light** - Philosophy of the kalashtar
4. **The Undying Court** - Elven ancestors worshipped by the Aereni elves
5. **The Dragon Below** - Cults that worship the dark powers of Khyber