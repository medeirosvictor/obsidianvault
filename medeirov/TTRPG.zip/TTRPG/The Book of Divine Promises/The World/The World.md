## 500 anos depois da Guerra da Marca
![[BookOfPromisesEventsTimeline.png]]

[[Previous Events]]
50 Anos de Guerra da Marca
200 anos de prosperidade
A Volta dos Poderes Primodiais e dos Deuses
250 anos de guerra
512 MR (Magic Rebirth)
  
- Magia ou canalização religiosa either banida em algumas cidades e geralmente mal olhada, minor magic ou healing as vezes recebe um passe mas pode ser que cobrem fees pra castar magia.
- Aparelhagem por cartucho e marcas ainda existem mas são mais caros.
- Cartuchos de magias fortes pedem uma troca em sangue alem do cartucho ser preenchido com sangue e a marca apagada, para recarregar ou comprar um novo ser tracked quem usou. Causa dependência mágica, ou o usuário vicia em magia ou o usuário perde magia.
- Veículos como hovers, trains e zeppelins existem.
- Sending “stones” existem como forma de telefone sem fio, abrir uma conexão usa o cartucho de sangue pra ambos os lados mas esse pode ser recarregado.
- Existem cerca de 3 marcas de grande poder Baldurs Gate Tomorrows Arc., Krosawall Originals Arc e Transparent Veil Arc.
- Twin Dragons Aerofacilities para aeronautas.
  
O estado futuro do mundo se trata quando os seres vivos conseguirem se aturar ao plano astral. Revelando novas subclasses astrais. Para isso os vivos devem através de meditação e atunacao com a natureza ao redor, conseguem acesso plano astral. Uma tribo ao norte, que no futuro ficaria conhecida como Godkin, influênciada pela marca, desenvolveu Astralis. Uma língua que permite a compreensão do mundo astral e de suas conexões com o plano material, estes com marcas no corpo conseguem produzir warmth, conseguem gerar pequenas quantidades de comida e água suficientes para sobreviverem em climas extremamente inóspitos. Um dia, um jovem garoto nasceu com habilidade de manipular símbolos arcanos e astrais sem a necessidade de marcas, foco ou coisa do tipo. A tribo numa sessão de meditação explorava o plano astral foi vista por um Deus que vagava pelo plano, vendo aquela transgressão decidiu punir os “mortais” por invadir seu reino.
A tribo e suas marcas podem “tatuar” os aventureiros para prover alguns benefícios:
- plane pocket para armas ou pequenos items, ate 3
- Plane blink, brief teletransporte de ate 30ft
- Plane deflect, basicamente counter attack ou counter spell
- Para todos, astral nourishment, enquanto medita podem passar ate 4hrs por long rest em light activity e consomem apenas meia ração por dia.
A familia de Hadron foi morta no plano astral, como vinganca Higgs prometeu se livrar dos Deuses. Fundou a alma matter para reunir legiões em busca da pacificação e da limpeza do mundo astral.
  
[[The Imperium]]
[[TTRPG/The Book of Divine Promises/The World/Alma Mater/Alma Mater]]
[[Godkin Race]]
[[Dragonmarks|Dragonmarks]]
[[Mage Seeker Archetypes]]
[[Deceased Gods so Far]]
[[Today]]
