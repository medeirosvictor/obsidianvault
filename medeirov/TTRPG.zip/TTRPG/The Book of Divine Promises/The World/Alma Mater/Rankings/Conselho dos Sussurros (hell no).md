### **Section 8.1  
Meus players acidentalmente What-if  
**  
  
**- on early branching encounters: Considerando mais de um presente no plano de X ou viajando por Y um encontro aqui seria straight forward TPK**
  
  
1. **Azura, a Voz Sombria**
    - Função: Azura é a principal estrategista do Conselho, especializada em manipulação psíquica e espionagem. Ela coordena as redes de espiões da Alma Mater, usando suas habilidades para influenciar decisões políticas em todo Faerûn.
    - Especialidade: Magia Psíquica e Controle Mental. Azura é capaz de invadir a mente de quase qualquer indivíduo, semeando desinformação ou extraindo segredos cruciais sem deixar vestígios.
    - **Habilidade Única:** "Eco da Desordem" – Azura pode plantar uma palavra sussurrada na mente de um alvo, que se propaga como um vírus, levando à paranoia e conflito interno. Esta habilidade é capaz de desestabilizar grupos, organizações e até governos inteiros, sem que jamais descubram sua verdadeira origem.  
          
          
        
2. **Thorm, o Guardião das Sombras**
    - Função: Responsável pela segurança interna do Conselho e pela execução de traições ou ameaças internas. Thorn é o braço direito de Elyrian em assuntos que requerem uma solução definitiva.
    - Especialidade: Assassínio e Ilusão. Utiliza sombras e ilusões para se mover não detectado, eliminando inimigos da Alma Mater com eficiência mortal.
    - **Habilidade Única:** "Abraço da Penumbra" – Thorn pode se tornar um com as sombras, permitindo-lhe atravessar paredes, aparecer atrás de seus alvos inesperadamente e até mesmo se tornar temporariamente intangível, tornando-o um assassino quase perfeito.  
          
          
        
3. **Cassian, o Tecelão de Destinos**
    - Função: Cassian trabalha próximo a Elyrian no desenvolvimento de novas formas de soulmancia e rituais que possam expandir o poder do Soulancer e do Conselho.
    - Especialidade: Alta Magia e Ritualística. Sua compreensão dos véus entre os mundos permite manipular o tecido da realidade, criando feitiços e maldições complexas.
    - **Habilidade Única:** "Fios do Destino" – Cassian pode manipular os eventos ao redor de uma pessoa, tecendo uma teia de destino que altera sutilmente o curso de suas ações. Esta habilidade permite que ele coloque ou remova obstáculos no caminho de seus alvos, direcionando o fluxo do destino a favor dos objetivos da Alma Mater.