### **1. O Soulmancer (Elyrian)**
- O líder supremo da Alma Mater, um mestre da soulmancia com visão e poder inigualáveis. Elyrian é a força motriz por trás dos objetivos e estratégias da organização.
### **2.** **Conselho dos Sussurros**
- Este grupo elite é composto pelos conselheiros mais próximos e de confiança de Elyrian. Eles são responsáveis por planejar e supervisionar as operações da Alma Mater em alto nível, agindo como os principais executores da vontade do Soulancer. Cada membro do Conselho dos Sussurros é um mestre em seu próprio direito, especializado em diferentes formas de manipulação, seja através de magia, influência política ou controle mental.
### **3.** **Guardiões do Véu**
- Encarregados de proteger os segredos da Alma Mater e assegurar a segurança de seus locais mais sagrados. Eles são altamente treinados em combate e técnicas de ocultação, servindo como a linha de defesa da organização contra ameaças externas e internas.
### **4.** **Tecelões de Ecos**
- Especialistas em soulmancia que se dedicam a expandir e aprofundar o conhecimento e uso dessa magia. Eles são encarregados de desenvolver novos feitiços e rituais, trabalhando sob a orientação do Conselho dos Sussurros para avançar os objetivos da Alma Mater.
### **Não Classificados (Peões)**
- Iniciados ou membros de baixo escalão que ainda não foram totalmente integrados ou confiáveis com os segredos mais profundos da Alma Mater. Eles realizam tarefas variadas, muitas vezes servindo como mão de obra descartável ou em funções que exigem pouca responsabilidade direta.
Essa estrutura de classificação reforça a natureza enigmática e a eficiência da Alma Mater, com cada nível contribuindo para a ambição de Elyrian de tecer seu domínio através de Faerûn.
[[Conselho dos Sussurros (hell no)]]
[[Guardiões do Véu (they hard but they might)]]