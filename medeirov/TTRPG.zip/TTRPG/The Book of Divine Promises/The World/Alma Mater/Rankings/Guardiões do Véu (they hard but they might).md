  
1. **Lyra, a Protetora Silenciosa**
    - Função: Lyra comanda a defesa das instalações secretas da Alma Mater, especializando-se na criação de barreiras mágicas e na detecção precoce de intrusos.
    - Especialidade: Magia Defensiva e Encantamentos. Suas habilidades permitem criar fortalezas praticamente impenetráveis ao redor dos locais sagrados da Alma Mater.
    - **Habilidade Única:** "Cúpula de Silêncio" – Lyra pode criar uma barreira mágica impenetrável que anula qualquer magia lançada contra ela ou contra estruturas protegidas. Dentro desta cúpula, nenhum som pode entrar ou sair, tornando-a uma defesa perfeita contra espionagem e ataques mágicos.  
          
          
        
2. **Darius, o Espadachim Etéreo**
    - Função: Darius lidera as forças de ataque dos Guardiões do Véu, focando em missões de alto risco contra inimigos poderosos da Alma Mater.
    - Especialidade: Combate Mágico e Táticas de Guerrilha. Com sua espada encantada, Darius pode cortar tanto a matéria quanto a magia, tornando-o um adversário temido no campo de batalha.
    - **Habilidade Única:** "Corte Etéreo" – Darius pode carregar sua espada com energia mágica, permitindo que seus golpes cortem através de feitiços, barreiras mágicas e até o tecido do espaço-tempo, criando portais curtos que ele pode usar para se mover rapidamente no campo de batalha.  
          
          
        
3. **Nimue, a Vidente das Sombras**
    
    - Função: Nimue usa suas habilidades de previsão para antecipar ataques contra a Alma Mater e para descobrir oportunidades de expandir seu poder.
    - Especialidade: Vidência e Previsão. Suas visões frequentemente revelam os movimentos dos inimigos da Alma Mater antes que eles aconteçam, permitindo que os Guardiões do Véu se preparem adequadamente.
    
    **Habilidade Única:** "Olhos do Futuro" – Nimue pode projetar sua consciência para o futuro próximo, permitindo-lhe ver os eventos antes que eles aconteçam. Esta habilidade lhe dá uma vantagem incrível em planejamento e estratégia, pois ela pode ajustar os planos da Alma Mater com base nas futuras probabilidades.