[[Guerra da Marca]]
[[Renascença da Magia]]
[[Guerra Santa]]
