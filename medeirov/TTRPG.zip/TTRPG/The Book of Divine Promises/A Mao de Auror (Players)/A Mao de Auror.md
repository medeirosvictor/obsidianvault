[[Characters]]
Elir Amitai
Hedwyn Mesikamen
Ratan Abah
Kawara Dura