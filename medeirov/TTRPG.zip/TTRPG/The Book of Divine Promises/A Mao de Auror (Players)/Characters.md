Auror Filis Magno
Aurora Filis Magno
Solas Meridiam
Lingget
Oakland
Juno