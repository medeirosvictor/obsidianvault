**Mark of Warding**
**Least**
_Alarm_, _arcane lock_, _fire trap_ or _misdirection_ once a day, and increased skill in searching.[[1]](https://eberron.fandom.com/wiki/Mark_of_Warding\#cite_note-ECS-p67-1)
**Lesser**
_Explosive runes_, _glyph of warding_ or _nondetection_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Warding\#cite_note-ECS-p67-1)
**Greater**
_Mordenkainen's faithful hound_, _greater glyph of warding_, or _guards and wards_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Warding\#cite_note-ECS-p67-1)
**Siberys**
_Prismatic wall_ once a day[[2]](https://eberron.fandom.com/wiki/Mark_of_Warding\#cite_note-ECS-p81-2)