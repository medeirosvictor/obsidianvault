**Mark of Handling**
Least
Natural intentions
Lesser
Charm friendly / Find Familiar
Greater
Tame Creature
Syberis
Astral Bound / Bestow intelligence