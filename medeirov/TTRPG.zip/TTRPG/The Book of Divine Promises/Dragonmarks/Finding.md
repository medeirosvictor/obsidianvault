**Mark of Finding**
**Least**
_Identify_ or _locate object_ once a day or _know direction_ twice a day; greater skill in searching for hidden things.[[1]](https://eberron.fandom.com/wiki/Mark_of_Finding\#cite_note-ECS-p63-1)
**Lesser**
_Helping hand_ or _locate creature_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Finding\#cite_note-ECS-p63-1)
**Greater**
_Find the path_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Finding\#cite_note-ECS-p63-1)
**Siberys**
_Discern location_ once a day[[2]](https://eberron.fandom.com/wiki/Mark_of_Finding\#cite_note-ECS-p81-2)