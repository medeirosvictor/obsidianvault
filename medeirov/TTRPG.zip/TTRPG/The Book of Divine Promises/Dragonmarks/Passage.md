**Mark of Passage**
**Least**
_Expeditious retreat_, _mount_, or _dimension leap_ once a day, and increased skill in survival.[[1]](https://eberron.fandom.com/wiki/Mark_of_Passage\#cite_note-ECS-p65-1)
**Lesser**
_Dimension door_ or _phantom steed_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Passage\#cite_note-ECS-p65-1)
**Greater**
_Overland flight_ or _teleport_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Passage\#cite_note-ECS-p65-1)
Unopened Doors x1
**Siberys**
_Greater teleport_ once a day[[2]](https://eberron.fandom.com/wiki/Mark_of_Passage\#cite_note-ECS-p81-2)