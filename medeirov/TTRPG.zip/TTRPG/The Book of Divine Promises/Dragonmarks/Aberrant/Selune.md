The scryers of selune managed to see who would be born with it given the prophecy of the dragons
