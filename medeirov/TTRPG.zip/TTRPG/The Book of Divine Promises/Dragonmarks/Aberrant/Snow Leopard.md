79 - chained morning star - regular chain with morning star ball attached to the end of it, reach of 10ft
32 - Shortbow
12 - harpoon launcher w rope - a rope gets attached somewher
66 - Flaming God Quarterstaff -Circle of Fire
96 - Bouncing chakram - For each succ attack roll, roll an extra one at the same target or different one up to 4 times
1. **28 - Frostbite Axe**: This axe emanates a freezing aura, dealing additional cold damage on hit and potentially slowing enemies.
2. **45 - Thunderbolt Crossbow**: A crossbow that fires bolts crackling with electrical energy, dealing extra lightning damage and potentially stunning targets.
3. **52 - Shadow Dagger**: This dagger casts darkness around its target on hit, granting advantage to the wielder's next attack against them.
4. **73 - Void Blade**: A blade infused with the power of the void, dealing extra necrotic damage and potentially draining life from enemies.
5. **82 - Gale Greatsword**: This greatsword creates gusts of wind with each swing, allowing the wielder to push enemies back or knock them prone.
6. **91 - Arcane Wand**: A wand that channels arcane energy, allowing the wielder to cast a random low-level spell upon successful attack.
7. **33 - Venomous Whip**: A whip coated in poison, dealing extra poison damage and potentially poisoning enemies, causing ongoing damage over time.
8. **62 - Celestial Bow**: A bow imbued with celestial energy, firing arrows of light that deal radiant damage and potentially blinding enemies.
9. **88 - Soulbound Mace**: A mace that binds the souls of defeated enemies, granting temporary hit points to the wielder upon each kill.
10. **17 - Earthshaker Warhammer**: This warhammer creates tremors upon impact, potentially knocking enemies prone or causing difficult terrain.
11. **39 - Phoenix Bow**: A bow that fires arrows wreathed in flames, dealing extra fire damage and potentially igniting enemies or surfaces.
12. **50 - Mirage Blade**: This sword distorts reality upon each swing, creating illusory duplicates of the wielder that confuse enemies and grant advantage on the next attack.
13. **68 - Spectral Scythe**: A scythe that summons spectral reapers with each swing, dealing extra necrotic damage and potentially fearing enemies.
14. **77 - Astral Lance**: A lance that pierces through dimensions, ignoring armor and potentially phasing through obstacles to hit its target.
15. **84 - Stormcaller Staff**: This staff summons thunderstorms with each strike, dealing extra lightning damage and potentially causing enemies to be struck by lightning.
16. **93 - Dreamcatcher Shield**: A shield adorned with dreamcatcher charms, granting the wielder resistance to psychic damage and potentially reflecting spells back at attackers.
17. **20 - Soulflayer Flail**: This flail drains the life force from enemies, healing the wielder for a portion of the damage dealt and potentially inflicting vulnerability to necrotic damage.
18. **55 - Chrono Dagger**: A dagger that manipulates time, allowing the wielder to briefly freeze or slow enemies upon successful hit.
19. **70 - Hydra Maul**: This maul splinters into multiple heads upon impact, dealing extra damage and potentially causing bleed damage over time.
20. **39 - Phoenix Bow**: A bow that fires arrows wreathed in flames, dealing extra fire damage and potentially igniting enemies or surfaces.
21. **50 - Mirage Blade**: This sword distorts reality upon each swing, creating illusory duplicates of the wielder that confuse enemies and grant advantage on the next attack.
22. **68 - Spectral Scythe**: A scythe that summons spectral reapers with each swing, dealing extra necrotic damage and potentially fearing enemies.
23. **77 - Astral Lance**: A lance that pierces through dimensions, ignoring armor and potentially phasing through obstacles to hit its target.
24. **84 - Stormcaller Staff**: This staff summons thunderstorms with each strike, dealing extra lightning damage and potentially causing enemies to be struck by lightning.
25. **93 - Dreamcatcher Shield**: A shield adorned with dreamcatcher charms, granting the wielder resistance to psychic damage and potentially reflecting spells back at attackers.
26. **20 - Soulflayer Flail**: This flail drains the life force from enemies, healing the wielder for a portion of the damage dealt and potentially inflicting vulnerability to necrotic damage.
27. **55 - Chrono Dagger**: A dagger that manipulates time, allowing the wielder to briefly freeze or slow enemies upon successful hit.
28. **70 - Hydra Maul**: This maul splinters into multiple heads upon impact, dealing extra damage and potentially causing bleed damage over time.
29. **01 - Shortsword**
30. **02 - Longsword**
31. **03 - Battleaxe**
32. **04 - Warhammer**
33. **05 - Dagger**
34. **06 - Quarterstaff**
35. **07 - Handaxe**
36. **08 - Mace**
37. **09 - Spear**
38. **10 - Crossbow**
39. **23 - Frostbite Pistol**: A sleek handgun that fires icy projectiles, freezing enemies in their tracks upon impact and slowing their movements for a brief duration.
40. **34 - Thunderclap Rifle**: A powerful rifle that unleashes booming thunder with each shot, potentially deafening enemies and disrupting their concentration.
41. **42 - Inferno Flamethrower**: This flamethrower spews forth a torrent of raging flames, setting enemies ablaze and igniting the surrounding area in a fiery inferno.
42. **56 - Shadowstep Dagger**: A dagger imbued with shadow magic, allowing the wielder to teleport short distances upon successful strikes, swiftly maneuvering in and out of combat.
43. **63 - Stormcaller Bow**: A bow that conjures lightning storms with each arrow fired, electrifying targets and potentially chaining lightning between enemies.
44. **71 - Phoenix Shield**: A shield adorned with phoenix feathers that erupts into flames when struck, engulfing nearby enemies in fire and providing temporary protection to allies.
45. 81 - Pode ficar com ele por mais 1 round
46. **82 - Soulrender Greatsword**: This greatsword drains the life force of its victims upon each swing, healing the wielder for a portion of the damage dealt and empowering them with renewed vigor.
47. 87 haste granade
48. **87 - Chrono Grenade**: A grenade that creates a temporal distortion upon detonation, slowing time within its blast radius and allowing allies to move and react more swiftly.
49. **94 - Celestial Knuckles**: Brass knuckles infused with celestial energy, striking foes with holy power and potentially banishing undead or fiendish creatures with each punch.
50. **100 - Void Nova Bomb**: A devastating explosive that tears open rifts to the void upon detonation, sucking enemies into its dark abyss and obliterating them with raw chaotic energy.