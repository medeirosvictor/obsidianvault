**Mark of Hospitality**
**Least**
_Unseen servant_ once a day or _purify food and drink_ or _prestidigitation_ twice a day; increased skill in diplomacy[[1]](https://eberron.fandom.com/wiki/Mark_of_Hospitality\#cite_note-ECS-p64-1)
**Lesser**
_Create food and water_ or _Leomund's secure shelter_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Hospitality\#cite_note-ECS-p64-1)
**Greater**
_Heroes feast_ or _Mordenkainen's magnificent mansion_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Hospitality\#cite_note-ECS-p64-1)
**Siberys**
_Refuge_ once a day[[2]](https://eberron.fandom.com/wiki/Mark_of_Hospitality\#cite_note-ECS-p81-2)