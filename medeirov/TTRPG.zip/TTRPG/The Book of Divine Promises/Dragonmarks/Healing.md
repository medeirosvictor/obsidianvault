**Mark of Healing**
**Least**
_Cure light wounds_ or _lesser restoration_ once a day; increased skill in healing[[1]](https://eberron.fandom.com/wiki/Mark_of_Healing\#cite_note-ECS-p63-1)
**Lesser**
_Cure serious wounds_, _neutralize poison_, _remove disease_ or _restoration_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Healing\#cite_note-ECS-p63-1)
**Greater**
_Heal_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Healing\#cite_note-ECS-p63-1)
**Siberys**
_Mass heal_ once a day[[2]](https://eberron.fandom.com/wiki/Mark_of_Healing\#cite_note-ECS-p81-2)