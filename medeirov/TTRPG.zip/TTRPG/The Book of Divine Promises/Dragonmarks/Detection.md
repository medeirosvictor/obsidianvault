**Mark of Detection**
**Least**
_Detect magic_ or _detect poison_ twice a day; increased skill in spotting things hidden.[[1]](https://eberron.fandom.com/wiki/Mark_of_Detection\#cite_note-ECS-p63-1)
**Lesser**
_Detect scrying_ or _see invisibility_ once a day.[[1]](https://eberron.fandom.com/wiki/Mark_of_Detection\#cite_note-ECS-p63-1)
**Greater**
_True seeing_ once a day.[[1]](https://eberron.fandom.com/wiki/Mark_of_Detection\#cite_note-ECS-p63-1)