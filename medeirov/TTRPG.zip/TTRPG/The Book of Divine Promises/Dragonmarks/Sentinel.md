**Mark of Sentinel**
**Least**
_Mage armor_, _protection from arrows_, _shield of faith_ or _shield other_ once a day, and increased skill in sensing deception and motive.[[1]](https://eberron.fandom.com/wiki/Mark_of_Sentinel\#cite_note-ECS-p66-1)
**Lesser**
_Protection from energy_ or _lesser globe of invulnerability_ once a day.[[1]](https://eberron.fandom.com/wiki/Mark_of_Sentinel\#cite_note-ECS-p66-1)
**Greater**
_Globe of invulnerability_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Sentinel\#cite_note-ECS-p66-1)
**Siberys**
_Mind blank_ once a day[[2]](https://eberron.fandom.com/wiki/Mark_of_Sentinel\#cite_note-ECS-p81-2)