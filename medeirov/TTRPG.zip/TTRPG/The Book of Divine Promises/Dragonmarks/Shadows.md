**Mark of Shadows**

**Least**
_Darkness_, _disguise self_, or _minor image_ once a day, and increased skill in gathering information;[[1]](https://eberron.fandom.com/wiki/Mark_of_Shadow\#cite_note-ECS-p66-1) or _knock_, _masking shroud_
**Lesser**
_Clairaudience/clairvoyance_, _shadow conjuration_ or _scrying_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Shadow\#cite_note-ECS-p66-1)
**Greater**
_Mislead_, _prying eyes_, or _shadow walk_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Shadow\#cite_note-ECS-p66-1)
**Siberys**
_Greater prying eyes_ or _greater scrying_ once a day[[5]](https://eberron.fandom.com/wiki/Mark_of_Shadow\#cite_note-ECS-p81-5)