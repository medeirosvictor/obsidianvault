**Mark of Scribing** 
**Least**
_Whispering wind_ or _comprehend languages_ once a day or _arcane mark_ twice a day, and skill in deciphering texts[[1]](https://eberron.fandom.com/wiki/Mark_of_Scribing\#cite_note-ECS-p65-1)
**Lesser**
_Illusory script_, _secret page_, or _tongues_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Scribing\#cite_note-ECS-p65-1)
**Greater**
_Sending_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Scribing\#cite_note-ECS-p65-1)
**Siberys**
_Symbol of death_ once a day[[2]](https://eberron.fandom.com/wiki/Mark_of_Scribing\#cite_note-ECS-p81-2)