**Mark of Storm**
**Least**
_Endure elements_, _fog clouds_, or _gust of wind_ once a day, and increased balance[[1]](https://eberron.fandom.com/wiki/Mark_of_Storm\#cite_note-ECS-p66-1)
**Lesser**
_Sleet storm_ (freezing or warm rain), _wind's favor_, or _wind wall_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Storm\#cite_note-ECS-p66-1)
**Greater**
_Control winds_ or _control weather_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Storm\#cite_note-ECS-p66-1)
**Siberys**
_Storm of vengeance_ once a day[[2]](https://eberron.fandom.com/wiki/Mark_of_Storm\#cite_note-ECS-p81-2)