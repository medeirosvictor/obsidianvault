**Mark of Making**
**Least**
_Make whole_ or _repair light damage_ once a day or _mending_ twice a day, and increased skill in crafting.[[1]](https://eberron.fandom.com/wiki/Mark_of_Making\#cite_note-ECS-p65-1)
**Lesser**
_Minor creation_ or _repair serious damage_ once a day.[[1]](https://eberron.fandom.com/wiki/Mark_of_Making\#cite_note-ECS-p65-1)
**Greater**
_Fabricate_ or _major creation_ once a day[[1]](https://eberron.fandom.com/wiki/Mark_of_Making\#cite_note-ECS-p65-1)
**Siberys**
_True creation_ once a day[[2]](https://eberron.fandom.com/wiki/Mark_of_Making\#cite_note-ECS-p81-2)