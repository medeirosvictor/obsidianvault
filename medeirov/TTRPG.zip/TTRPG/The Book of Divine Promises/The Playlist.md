General:
[Desert Excursion | D&D/TTRPG Music | 1 Hour (youtube.com)](https://www.youtube.com/watch?v=maYRisfQQvc)
[Desert Ruins | D&D/TTRPG Music | 1 Hour (youtube.com)](https://www.youtube.com/watch?v=46w8MRZKj64)
[Dark Desert Music [ 1 hour ambient mix ] (youtube.com)](https://www.youtube.com/watch?v=Vo7n4j3OrNs)
[Warhead Storage (Metal Gear Solid Cover) [Hour Loop] (youtube.com)](https://www.youtube.com/watch?v=v379ZGDo2pg)
[Wulfsige - HEAVY IS THE CROWN - 2023 (Dungeon Synth, Ambient) (youtube.com)](https://www.youtube.com/watch?v=DNEam-XyvbE)
  
[Arabian Nights | D&D/TTRPG Music | 1 Hour (youtube.com)](https://www.youtube.com/watch?v=_38NQhaqs6g)
  
[Ashatan Desert Battle Music (youtube.com)](https://www.youtube.com/watch?v=0tfGjnV7g9U&t=392s)
  
[Spooky Cave | D&D/TTRPG Music | 1 Hour (youtube.com)](https://www.youtube.com/watch?v=LAO0LoXDQLs)
  
[Tavern in a Desert | D&D/TTRPG Tavern/Inn Music | 1 Hour (youtube.com)](https://www.youtube.com/watch?v=dhA8BtU8MaI)
  
[Istanbul Dreams | Instrumental Turkish Lounge Music (youtube.com)](https://www.youtube.com/watch?v=OWWJlWOjsDs)
  
[Assassin's Creed - Masyaf In Danger (Track 08) (youtube.com)](https://www.youtube.com/watch?v=athauZRhbwQ&list=PLu6_FOgZp3egxmTWGAOFlkuTyZRhE_cQc&index=5)
  
[A City in Sorrow | D&D/TTRPG Music | 1 Hour (youtube.com)](https://www.youtube.com/watch?v=fXA8zHLdYF0)
  
Suspense
[Metal Gear Solid 2: Tanker Deck C music 12 hours (youtube.com)](https://www.youtube.com/watch?v=tAhWAOnMgHA)
[The One Ring Theme / Music (Lord Of The Rings) (youtube.com)](https://www.youtube.com/watch?v=GuiROE85RMQ)
[Gwely Mernans - YouTube](https://www.youtube.com/watch?v=e91z7Po_w2E)
[Ghost - Spoksonat (Audio) - YouTube](https://www.youtube.com/watch?v=6BSKDSdvyok)
[(1) VGM Picks 19 - Chrono Cross - Viper Manor - YouTube](https://www.youtube.com/watch?v=jRy_exCrUVk)
[https://www.youtube.com/watch?v=evpoQPriwZs](https://www.youtube.com/watch?v=evpoQPriwZs)
  
Sad Pondering:
[Hy A Scullyas Lyf Adhagrow - YouTube](https://www.youtube.com/watch?v=Bj-VtZ1wRq4)
  
Chill Pondering:
[Jynweythek - YouTube](https://www.youtube.com/watch?v=htUalPYmIxk)
  
[(1) Western Ambience | Red Dead Redemption Inspired 1 Hour Music & Nature - YouTube](https://www.youtube.com/watch?v=5uLy6QIAK_I)
  
[Wizards of Aldur - Queen of Sorcery (Fantasy Synth) (youtube.com)](https://www.youtube.com/watch?v=4_k_kixX934)