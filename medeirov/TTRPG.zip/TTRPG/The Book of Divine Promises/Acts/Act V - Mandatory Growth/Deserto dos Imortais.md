Retirement community for godlike entities
