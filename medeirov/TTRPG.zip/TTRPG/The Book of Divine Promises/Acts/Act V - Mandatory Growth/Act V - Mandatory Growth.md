[[Floresta dos Deuses-Imortais]]
[[Deserto dos Imortais]]