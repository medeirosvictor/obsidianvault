Hedwyn
true - wants to free the use of magic, even at some costs  
kinda true - can tell unreliable divinations, omens and meanings  
false - is working to empower religion back  
Elir
True  
E’lir foi adotado por um sacerdote de Heliod e não sabe a própria idade.  
E’lir tem medo de estar fazendo um péssimo serviço em nome de Heliod, porque tem matado muita gente.  
Kinda true  
E’lir acha que tem um irmão e uma irmã discípulos, Simon e Gwen, mas não se lembra bem deles.  
E’lir estuda magia e música em livros quando tem oportunidade.  
Not true  
E’lir acidentalmente causou a destruição da vila e do templo onde cresceu.  
E’lir é descendente de Jonah Smith.  
  
Ratan
True - Ratan acha que está mais longe de aprender o que é "verdadeira neutralidade" do que quando começou sua jornada, e isso deixa ele meio depressivo por achar que está indo contra o que seu destino mandou  
Half True - Ratan ainda está sob o controle dos alma mater, mas é um sleeper agent que sempre vai jogar dúvida em cima da rightousness de aniquilar todos os alma mater  
Lie - Ratan está obcecado por uma magia proibida e secretamente trocaria tudo que ele tem em prol de desvendar seus mistérios (death mark)