Falaram com o Lazaro que vai em busca da Floresta dos Deuses. Foram introduzidos a ideia de roubarem um spelljammer no plano astral, dos alma matter, para irem ate a tormenta Arcana.
Investigaram um dos main tuneis do railway de calimport e descobriram a entrada para embaixo do palacio imperial, os carts cheio de dinamites e explosivos. Que possivelmente detonariam embaixo. Encontraram la a hive que seria despertada para atacar calimport. Nas coisas de Kemps vao descobrir o plano completo em seu tear-journal.
  
  
- Execucao de Mathias Lenore e seu assistent, nas masmorras do palacio. Kemps estara presente e ativara o cart se possivel;
- Conversa com Straza e Imperatriz; Execucao daqueles que estao marcados como possiveis traidores;
- Sugestao de uma das familias para uma familia eleita ser represetante dos interesses publicos de calimport;
![[NimuesTower.png|NimuesTower.png]]
![[NimuePenumbraDragon.png]]
![[Nimue.png|Nimue.png]]