Encontra os aventureiros nos jardins de calimsham uma de varias tavernas locais, em upper town. La ela revela que suspeita das acoes de alguns higher ups e que sente uma movimentacao politica, imagina que imperatriz pode estar in ou em perigo
  
Ela precisa de informacoes e tem suas leads principais, Warmfeather eh uma delas e ela pretende investigar seu estate no centro soon. Outros 4 senadores tambem devem ser investigados mas o acesso a eles eh bastante complicado;
  
Viper revela que o senador de assuntos militares reforcou a ideia de mais warforgeds e mageseekers nos portoes da cidade e outer borders, investigando quem entra e sai com mais severidade. Existe a proposal financeira agora para viabilizar uma reforma no sistema de esgotos e tuneis antigos da cidade. Uma preocupacao vem mais a tona com assassinatos aconcetendo no centro da cidade, os Rattle snakes tem um lider que deve ser encontrado e brought to light, mais dinheiro deve ser investido para chamar uma forma militar extra… os nobunaga
  
  
Vipers Secrets
[(4) Hades - On the Coast - YouTube](https://www.youtube.com/watch?v=ItLaESz43N0&list=RDMM&index=16)
Combat
[(4) 42. The Shrike Hills Battle Theme - YouTube](https://www.youtube.com/watch?v=3Pg5hnT5DdI&list=PLAMGM1hSRIUotAwIZu0_qN_xcNSXWaSpv&index=42)