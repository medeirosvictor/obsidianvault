Os encontra na arena ou pela cidade a noite, um kobold vindo do plano astral revela que esteve no primeiro ataque de Elyrian, contra helm, invadindo pelo plano material (cerca de 2 anos atras).
Diz ser um aliado e que pode prover mais informacoes sobre o templo de Heliod se aguardarem mais alguns dias, os alma mater estao em calimsham e ele tem acompanhado o sumisso de varios e o unrest da populacao.
Surya procura se vingar de “”calvinho” alma mater responsavel por destruir o templo de helm junto com seus mestres antes de fugir do nada para o plano astral.
  
Pediram a Surya para encontrar o templo de heliod, o melhor que ele consegue eh dizer que a entrada das ruinas templo fica no centro da cidade de calimport;