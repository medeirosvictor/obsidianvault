  
[(4) Mage Battle | D&D/TTRPG Battle/Combat/Fight Music | 1 Hour - YouTube](https://www.youtube.com/watch?v=Cnse9bjma9s&list=PLPkQh2SAuabExfT0ufQXMtSIIAFvRM5vH&index=13)