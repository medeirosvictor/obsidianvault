  
Exploring the ruins
[Legends of Runeterra - Temple of the Sun Extended Board Soundtrack (youtube.com)](https://www.youtube.com/watch?v=gVk0csH3FF0&list=RDMM&index=14)
  
Entering the campo de centeio
[Naruto Shippuden - Yogensha [Extended] (youtube.com)](https://www.youtube.com/watch?v=FVbZfxysGMo&list=LL&index=167)
[Naruto Shippuden - Madara Uchiha Theme (Six Paths) (youtube.com)](https://www.youtube.com/watch?v=ExxW5HUUWfI&list=LL&index=199)
  
Fighting new born god of the sun, heliods demise -
[Bloodborne Soundtrack OST - Gehrman, The First Hunter (youtube.com)](https://www.youtube.com/watch?v=3V9zxXN1rx0&list=PLbwEH6HDYMW2wKOhvAeRIXH-L1ZYBXFZ2&index=5)
In a realm where the sun's reign knows no bound,  
Stands a statue, in praise, it is found.  
Upon its pedestal, reaching for the sky,  
The sun god's gaze seems to never shy.  
Yet in the shadow's embrace,  
The statue stands in silent grace.  
Ease the eyes and show the way  
Heliod’s enlightment never sways  
  
  
Roger
  
Unborn Heliod Vessel
Piping hot armor - grapple 2d4
Sun beam - mouth casting 5 targets
second phase
solar flare blind and damage
fire and divine aura, resistance to the god and its subjects
  
  
After defeating heliods newborn, the players find themselves in the Sun God astral retreat.
They can still go back and visit other areas in calimport and can stay and be basically destroyed by the Alma matter forces that will appear soon. The mark of passage will lead them to a dark room where they will meet one of the Lyra the protector, the one that was guiding Roger into the upper ranks.