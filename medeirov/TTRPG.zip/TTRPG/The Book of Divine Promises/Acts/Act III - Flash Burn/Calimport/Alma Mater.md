Solas, Kemps e Oakland ja chegaram a calimsham fazem 4 dias e ja apresentaram Kemps ao Senador de Arma, info referente a reuniao com Viper Nimbus indica o desejo do senador.
  
Solas has Khan and the dogs trapped in one of the towers of the Sun Dial as spies from the outer worlds. He leaves the city in a few days after Kemps is appointed subtitute senator