- The arena's entrance is flanked by imposing statues of legendary gladiators, their weapons raised triumphantly.
- The stands are filled with spectators from all walks of life, cheering and jeering as combatants clash in the arena below.
- Vendors roam the stands, hawking snacks and souvenirs adorned with the emblem of the arena.
  
Lion of the Desert - Dark skin barbarian orc with an aberrant dragonmark, being sponsored by secret alma matters
Aegis - 4 armed warforged fighter with shields in each arm
Lagrange - A tiefling warlock with a misterious pact
**Spectral Serpent -** A ghostly yuan-ti eldritch knight, haunting the arena with spectral weapons and serpentine grace. Their mastery of both sword and spell, combined with their serpentine heritage, makes them a formidable opponent, blending martial prowess with arcane power and the deadly cunning of a serpent.  
  
**Ironclad Titan -** A towering warforged paladin clad in heavy armor adorned with intricate engravings. With a massive warhammer in hand, they exemplify unwavering strength and unyielding resolve, earning respect and fear alike from their opponents.  
  
  
**Blade Tempest -** A nimble elven rogue known for their lightning-fast strikes and elusive maneuvers. Their dual-wielded scimitars leave a trail of whirling blades in their wake, earning them the nickname "Blade Tempest" among the arena's spectators.  
  
  
  
1. **Shadowblade -** A brooding half-elf assassin who specializes in stealth and deception. Armed with a pair of wickedly sharp daggers and clad in dark leather armor, they lurk in the shadows, waiting for the perfect moment to strike with deadly precision.
2. **Brawler Bruiser -** A boisterous human brawler who relies on brute force and street smarts to win fights. With fists like hammers and a sturdy constitution, they charge into the fray with reckless abandon, delivering bone-crushing blows and shrugging off their opponents' attacks.
3. **Arcane Novice -** A timid gnome wizard who is still learning the ropes of magic. Armed with a battered spellbook and a few basic spells, they stumble and fumble their way through the arena, casting spells with uncertain precision and often resorting to desperate tactics to survive.
  
Prego - possesses abherrant mark, lives on the street and it is possibly going to kill himself. New class yet to be discovered by me.