Um castelo negro rodeado por casas menores e cercado por uma muralha roxa escura kilometrica repousa escorada nas montanhas Dragonspine. Uma ponte arquea ate o portao gigante da entrada que eh vigiado por alguns guardas. Estes abordam a carruagem dos aventureiros ao se aproximarem.
Dois guardas, **Lockless e Whilma**, ambos usando uma armadura de couro negra com detalhes roxo escuro e capas com uma fivela no ombro esquerdo de uma pena escura, param os aventureiros perguntando:
- O seu negocio na citadela;
- Quanto tempo tem viajado e pedem um passe de inspecao de mage seekers;
- Pedem uma quantia de 5 gp para entrarem na cidade e emitir um registro valido por 10 dias para permanecer na cidade e registrar o veiculo
  
Corvo Viajante - General Goods store, operada como um supermarket com selfcheckout feito por corvos magicos
**DarkIron Forge and Workshop** - operada por Martin Fleetstone, um anao gordo careca de bracos enormes usando um avental por cima do corpo e uma calca suja. 
- Operada por Trion Warforged e Joselyn
Mystic Grove Trinkets
Estalagem do **Raven’s Nest** - Fortaleza com chales um bar central e um pit de lutas no centro.
  
![[RoomPrices.png|RoomPrices.png]]
![[FoodAndDrinkPrices.png|FoodAndDrinkPrices.png]]
The Raven Queen- Comandado por Gideon Loss um Humano, que previamente servia de conselheiro para Alistaer Nightshade que perdeu sua filha Marian Nightshade, barao que foi desposed do comando. A historia contada eh de que ele foi forcado a se aposentar e se reclusou para seu estate nas montanhas. O castelo se encontra no centro da encosta da montanha e como uma estatua gigante observa a cidade que descede ao nivel do mar.
  
Descricao do Castelo: No extremo oposto do salão, um trono majestoso esculpido em obsidiana repousa, símbolo de autoridade e poder As paredes de pedra escura do castelo, desgastadas pelo tempo e pelas sombras, são testemunhas de séculos de história e fortificação. Torres imponentes adornadas com gárgulas e ameias vigiam as terras ao redor, suas silhuetas cortando uma figura imponente contra o céu crepuscular. A entrada do castelo é guardada por um par de portões maciços de ferro, cada um adornado intricadamente com o emblema de um corvo em voo. Ao passar por eles, revela-se o pátio principal, uma vasta extensão cercada por muros altos e ladeada por torres imponentes.

Temporariamente estacionados no Ninho do Corvo, a Mao de Auror percebe que talvez tenha se exposto demais. Uma teia de mentiras que contaram para se manterem seguros comeca a desmoronar e percebem que mage seekers estao na cidade enquanto buscam uma forma de encontrar o ex barao da cidadela dos corvos, Alistaer. Ainda em posse do corpo de sua filha a Mao de Auror percebe que a cidadela tambem parece compartilhar, aparentemente, de um presente e futuro similar ao de Palewind.
Aqui os aventureiros podem escolher entre algumas formas de se infiltrar no castelo ou no hangar acima do castelo.
- Casual sneak;
- Brute force;
- Alma Mater Meetings;
  
Layout do Castelo → Paths para o Hangar → encontro de pistas sobre o paradeiro do ex barao da cidadela dos corvos
O castelos tem os seguinte andares:
- ==Saguao de agendamento com o Barao==
Os aventureiros ja estiveram aqui, sala escura feita em obsidiana. Um bardo toca ao fundo e muitos dependendo da hora aguardam sua vez de falar com o Barao. 4 soldados e um mesario que tambem aparenta ser militar, estao no local. Uma area de bar na direita e algus servicais complementam a experiencia de se esperar.
- ==O hall da cozinha==
Um andar todo dedicado a cozinha, areas para tratar animais de quase qualquer tamanho, fogoes, geladeiras e mesas de preparo alem de cabinetes quase que interminaveis de temperos e outros ingredientes.
- ==Os dormitorios dos trabalhadores==
Um corredor com basicamente kitnets para a guarda do barao, antigamente quartos de hospedes mas reformados e designados para os guardas
- ==A torre do mago==
Tambem ja visitada pelos aventureiros, a torre redonda de Malachi um elfo educado e lawful com seu teto espelhado para as constelacoes.
- ==O dormitorio do Barao==
Contem 2 quartos e um master quarto para o barao, contem uma passagem secreta para uma sala de piscina e nela outra passagem para uma sala de rituais de alma matter
- ==Hangar==
Onde ficam as airships e os shadowings utilizados pela elite dos guardas da Cidadela dos Corvos
- ==Party Hall==
Onde sao hosteadas as festas de funding da cidadela dentre outros eventos reais.

[[Back from the Astral Memories]]
[[II. Castle of Ravens]]
[[III. Inside the Obsidian Walls]]
[[IV. Gone with the Wind]]