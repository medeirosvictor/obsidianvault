Os aventureiros após recuperarem a memória no templo de Silvanus e presenciarem o que pareceu ser a morte de ambos os aspectos de Silvanus decidem seguir em frente na sua aventura. Existem aqui varias possibilidades de para onde os aventureiros podem querer serguir.
1. Voltar para Palewind (Comandada por Solas em um regime mais restrito)
2. Ir para o Castelo dos Corvos (Castelo negro, similar a palewind mas mais high end e exclusivo)
3. Ir para Thar (destruída e pos apocalipticamente abandonada).
Incialmente em termos de recap, aqui esta o que os players experienciaram e o que sabem ate o momento.
- Egnever RIP (A introduzir novo personagem de Victor Lopes at some point, bladesinger)
- Hedwyn numa experience entre-morte no deserto das luas de selune
- Elir no seu aeroship também em contato com Heliod
- Se lembram que passaram cerca de 1 ano juntos. Para Kawara, Akira ainda esta vivo e Muraki esta por ai.
- Para Hedwyn ele saiu em busca de um templo de Selune para responder suas perguntas sobre sua primeira visão de Selune one ela corria num deserto com marcas de batalha.
- Elir lembra que sabe o nome de jonah Smith e o aeronauta Maxim que talvez possua mais informações. Ainda não sabe o seu propósito final
- Shadow Prince lembra de ter informações sobre quem o vendeu para seu mestre e de um recado do seu mestre pedindo para que o encontrasse onde se conheceram pela primeira vez.
- Em conhecimento sobre o que tem Alma Matter, parecem ser uma
Inicialmente as memorias sao removidas do corpo, para romper os attachments ao mundo material. As projecoes dessas memorias sao enviadas ao mundo astral e um corpo virgem e jovem, capaz de gerar vida (por algum motivo desconhecido) eh o que mantem o cristal de soumancia referenciado como Projetor ativo e vice versa, o cristal tambem mantem o corpo da mulher suspenso em vida por tempo indeterminado. Com a projecao no mundo astral feita, os Alma matter constroem um exercito feito para invadir e overwhelm os Deuses que vivem no mundo astral e limitam as almas do mundo material ao plano ethereal.
- Hedwyn havia tido uma sonho onde ele via Selune sendo cacada por um deserto com um céu astral. Ela pedia ajuda, com um vestido coberto por uma armadura destruída.
- Elir conhecia o nome Jonah Smith e sabia o nome do aeronauta Maxim que o conhecia por ultimo e sabia que estava vivo, estava em busca de encontrar o aeroplano e conversar com ele para saber mais.
- Kawara tinha encontrado uma pista de onde Akira estava, no norte de Faerun e o buscava para um duelo final. Mais repostas podem vir de Muraki.
- Shadow Prince lembra que havia recebido uma carta enquanto viajava pela sword coast, com a handwriting de seu antigo mestre ela fala para que se encontrassem onde se conheceram pela primeira vez. Numa das ilhas do sul de Faerun, onde seu mestre o comprou ainda como um ovo.
- Egnever lembra que ele estava em busca do refugio das plumas, havia descoberto que existia um monastério irmão ao seu, estaria também destruído? Encontraria mais repostas?
- Lembram-se que se conheceram ao longo do caminho. Primeiro, Hedwyn enquanto viajava por Faerun juntamente com Elir se conheceram num dos ambientes de prece conjunta em baldurs gate, partiram para uma missão de ajudar a trazer de volta um garotinho perdido. Shadow Prince viria a ser o nativo de baldurs gate que forneceu informações de ultimo paradeiro e de suspeitas. Interessado também resolveu participar. Numa viagem mais uns meses a frente, conheceram Kawara e Egnever que também estavam no navio, um motim explodiu no navio e os 5 tiveram que cobrir as próprias costas para escapar. Estiveram juntos desde então, por cerca de 1 ano e 6 meses.
  

  
  
Depois de derrotar Guideon com a ajuda do Corosine, a mao de auror consegue encontrar a tribo do norte dos godkin (Auroraheim Clan of the Frost Divines). Ali os players
**Castle Amidst the Snow Dune:**
As the players venture through the wintry expanse of the far north, they come upon a mesmerizing sight—an otherworldly castle seemingly crafted from ice and crystalline structures, nestled within a colossal snow dune. The castle stands as a testament to the Aurora Zenithar's mastery of ancient magic and their harmonious connection with the astral energies of the polar region.
**Exterior:**
- **Glacial Towers:** Towering crystalline spires jut upward from the snow dune, their surfaces shimmering with a soft, iridescent glow reminiscent of the auroras. These towers are adorned with intricate carvings depicting celestial phenomena and arcane symbols.
- **Icy Ramparts:** A fortified wall of ice and enchanted snow forms a protective barrier around the castle. Magical sigils and dragonmark-like runes etched into the walls resonate with latent energy, pulsating softly in the frosty air.
- **Aurora Veil:** Wisps of ethereal, multicolored lights dance above the castle, casting an enchanting aurora veil that shrouds the surroundings in a mystical ambiance, offering a glimpse of the tribe's attunement to astral energies.
**Interior:**
- **Crystalline Halls:** Within the castle's interior, corridors and halls crafted from translucent ice and crystal exude an otherworldly luminescence. The walls are adorned with tapestries depicting cosmic vistas, celestial beings, and the tribe's history.
- **Great Hall of Wisdom:** The heart of the castle holds the Great Hall of Wisdom—a grand chamber adorned with floating orbs of astral light. Here, Godkin elders and scholars convene, surrounded by arcane tomes and artifacts imbued with ancient knowledge.
- **Spires of Meditation:** Spiraling staircases lead to secluded spires where individual Godkin engage in deep meditation and study, seeking enlightenment amidst the celestial energies that permeate these chambers.
**Atmosphere:**
- **Sublime Silence:** A serene tranquility envelops the castle, broken only by the occasional echo of a distant chant or the soft hum of astral resonance. The air is crisp, carrying the faint scent of frost and arcane energies.
- **Whispers of the Astral:** Visitors might perceive faint whispers in the air, voices seemingly carried from distant planes, hinting at the Godkin's communion with astral entities and cosmic consciousness.
  
Khron e Sene, convidam os aventureiros a se hospedarem la e podem oferecer:
- Historia completa + recap dos Godkin e sua raca em geral
- Armas, items;
- Teleporte a Baldurs Gate/Sword Coast - Calimsham (Cloven Mountains);
- Alguns tipos de marcas:  
    - Astral Momentum (Reaction para absorver 1 ataque e lanca-lo devolta com uma reaction, pode guardar o ataque por 8 horas no tier mais baixo)  
    -  
    
1. **Ethereal Resonance** - The player gains an enhanced connection to astral energies, allowing them to pass through solid objects briefly. Once per short rest, the player can use an action to become incorporeal for a brief duration, moving through obstacles or evading attacks without provoking opportunity attacks.
2. **Aurora's Embrace** - The tattoo enhances the player's natural resilience. Once per long rest, as a reaction to taking damage, the player can activate the rune, creating an ethereal barrier that absorbs the incoming damage, converting a portion of it into temporary hit points.
3. **Cosmic Insight** - This rune empowers the player's senses. Once per short rest, the player can spend an action to gain a temporary advantage on all Wisdom and Intelligence-based ability checks or saving throws for one minute.
4. **Astral Echoes** - The player gains the ability to create illusions imbued with astral energy. Once per short rest, the player can use an action to create illusory duplicates of themselves. These duplicates can move independently and mimic the player's actions for a duration of one minute, providing a distraction or aiding in combat.
5. **Ethereal Blade** - The player temporarily summons an ethereal blade from the astral realm. Once per long rest, as a bonus action, the player conjures a shimmering blade made of pure astral energy. This weapon is considered magical and on a successfull attack it give the info on the targets AC and reduces it by 1 or increases it by 1. The wielder must hold the weapon in at least one hand at all time to keep it active for 8 hours.
6. **Serene Mastery:** The rune grants the player mastery over mental focus. Once per long rest, as an action, the player enters a state of heightened concentration, allowing them to maintain concentration on two spells or abilities simultaneously for a limited duration
7. **Void Shield** - The player generates a protective shield that absorbs incoming damage. Once per short rest, as a reaction to taking damage, the player can activate the rune, creating an astral shield that reduces the damage received for a certain duration or until a certain amount of damage is absorbed turning half of the damage into temporary hit points.
8. **Astral Frenzy** - This rune enhances the player's combat abilities temporarily. Once per long rest, the player can activate the rune as a bonus action, entering a state of heightened combat prowess. For the combat duration, they gain an advantage on attack rolls and deal additional damage with their attacks. Several random astral weapons appear in the wielder's hand and he must attack with the weapon, it disappears after the attack. If the player does not attack its round with the spawned weapon, it takes 2d4 psychic damage and the effect ends
9. **Hereditary Prowess** - Once per long rest, as an action, the player can activate the rune. For one minute, they can add their proficiency again (if not already proficient) in a specific skill or ability that is deeply rooted in their bloodline or heritage. This newfound proficiency is bolstered by their ancestors' prowess, providing an advantage on related skill checks, ability checks, or granting a bonus to related actions, depending on the nature of their lineage.
  
1. **Ethereal Resonance** - **Snow Leopard**: Agile and elusive, much like the player passing through obstacles, the snow leopard represents grace and the ability to move swiftly and unnoticed.
2. **Aurora's Embrace** - **Tortoise**: Symbolizing resilience and protection, the tortoise reflects the ability to create a barrier and convert damage into temporary hit points, embodying enduring defense.
3. **Cosmic Insight** - **Owl**: Known for wisdom and acute senses, the owl signifies heightened perception and intelligence, granting the player an advantage on Wisdom and Intelligence-based checks.
4. **Astral Echoes** - **Fox**: Representing cunning and illusion, the fox embodies the creation of illusory duplicates, mirroring the player's actions and providing deceptive distractions in combat.
5. **Ethereal Blade** - **Raven**: The raven, associated with magic and mystery, signifies the conjuring of an astral blade, granting insight into the target's defenses while wielding the ethereal weapon.
6. **Serene Mastery** - **Mantis**: Known for focus and precision in martial arts, the mantis reflects the heightened concentration to maintain multiple spells or abilities simultaneously.
7. **Void Shield** - **Bear**: Symbolizing protection and endurance, the bear represents the generation of a protective astral shield that absorbs damage, converting a portion into temporary hit points.
8. **Astral Frenzy** - **Octopus**: The octopus, known for versatility and quick adaptation, signifies the temporary enhancement of combat abilities and the manifestation of astral weapons, emphasizing adaptability in battle.
9. **Hereditary Prowess** - **Dragon**: As a symbol of lineage, wisdom, and power, the dragon represents the player's ancestral skill proficiency, embodying the legacy and prowess passed down through generations.
  
  
Apos serem welcomed pelos godkin a mao de auror recebe os as marcas animais como ajuda em sua jornada alem do abrigo e comida que recebem da tribo do norte. Kaiser, buscando mais informacoes sobre Triss, pede que um ritual seja conduzido em que os elders e experientes da tribo buscam uma marca da morte. Utilizando a mark of death tier 2, eles conseguem descobrir que Triss nao possui a marca mas que esta no plano astral. A mao suspeita de que os Godkin escondem segredos da marca ou que proibem seu uso de forma inadequada, source of truth:
- A marca representa as duas faces da moeda de balance: o nome real da marca se chama mark of equilibrium e a marca funciona como binding vow e geradores de contratos. A marca to end all marcas, basta oferecer uma troca equivalente. entretanto, um conhecimento perdido a muitos godkin sobre a marca revela que o grande problema de utiliza-la sao os demonios dentro de cada um, se nao estiverem em cheque o preco pago sempre eh imbalanceado e a marca naturalmente cobra o preco em sanidade e outros aspectos. O nome marca da morte vem pois a constante imbalance da utilizacao da marca acaba fazendo com que os usuarios saiam do controle.
- esse eh o unico conhecimento nao livremente compartilhado dos Godkin, poucos conhecem sobre e muitos sao sugeridos a nao utilizar. The forbidden fruit que muitos ancioes acreditam que apenas os mais sabios e de will mais forte podem wieldear a marca
- Nao existe punicao ou proibicao por parte dos Godkin mas a recomendacao eh de que nao se estude essa marca em especifico;
  
Daqui os players podem fazer algumas coisas:
1. Investigar Auroraheim por pistas (quarto de higherups ou investigar lugares mais secretos);
2. Teleport to God of Snowfall Temple (White veil maiden as refered by suditos)  
    Em uma prairy onde a neve cai suavemente no que parece ser o comeco ou o fim do inverno, um swamp de lama e neve guia os players ate a entrada de uma igreja singela e antiga, com apenas uma double door e janelas aos lados, como uma classica igreja catolica. Cabendo cerca de 100 pessoas no maximo, ao se aproximar da porta e tentar abri-la uma voz vai greetear os aventureiros uma voz rusted e um pouco grave diz: “Quem vem la? se envergonham pela queda ou rastejam pelo mangue de neve em busca de salvacao”  
      
    
"As angels descend from heavens high,  
A soft embrace from the azure sky.  
Covering all with a silent hum,  
Always atop, as if the sun.  
What am I, in the calm of night?  
In winter's touch, a tranquil sight."  
  
  
Ir para Calimsham (old west vibes depois de viajar pelas Cloven Mountains)
Kron, Sene, Oni
Khan, Shuster, Don

[[Citadel of the Raven]]
