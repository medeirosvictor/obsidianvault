Os aventureiros conseguem sair do Castelo dos Corvos e seguem de volta para sua estalagem, Ninho do Corvo. Chegando la, ainda de noite, se pararam para partir pois os Alma Matter que infectaram o círculo baronesco da região sabem de suas intrusões. Ao buscar suas coisas em seu chalé, são interceptadas por 2 Mage Seekers, canceladores de magia com um olhar.
Furtivamente ate um ultimo momento eles conseguem escapar entre os estrondos de uma bola de fogo castada por Vouli. Em disparada dentro de sua carruagem quase roubada, conseguem informações de um livro misterioso. Alguém parece se comunicar através do livro e consegue uma dica de onde poderiam se esconder dentro da cidadela dos corvos, no cemitério nas tumbas da realeza da região. Depois de alguns percalços menores, sabendo que a guarda esta nos portões a mão de autor encontra uma tumba abandonada e decidem dormir por ali;
Pela manha encontram uma passagem secreta levando ate o que parece ser a parte interna da muralha da cidadela, encontram uma pequena porta que leva ao lado de fora da mesma para dentro do bosque da montanha espinha de dragão. Investigando o interior se deparam com um Sentinela da Muralha, um corvo gigante que patrulha os interiores. Uma batalha difícil se trava mas a Mao de Auror segue vitoriosa.
  
Opções a se preparar:
- Seguir muralha a dentro:  
    - Caminho a dentro;  
    - Subida para o castelo/hangar;  
    
- Sair pelo bosque em busca do antigo barão que parece ter fugido por ali:  
    - Viagem sem carruagem por um bosque denso  
    
- Voltar atrás e mudar de ideia:
Os aventureiros seguem dentro da muralha e conseguem mais informações com o sentinela e investigando dois esqueletos
Descobrem como algumas marcas funcionam e o nome de algumas delas. Um livro que tentava se esconder.
  
Vão seguir em frente dentro da muralha e devem encontrar a primeira inverted shadow fell waterfall elevator. Teste de constituição para serem levados para cima unless eles tenham o pin da raven queen.
- pins encontrados em cada corpo adormecido, marcas na boca. (Para serem ativados depois mas os players podem acidentalmente encadear uma sequencia de acordamentos)
- Cada soulmancer consegue catalizar a vítima a si mesmo, trazendo mais forca a sua existência.
  
  
Os aventureiros continuam a caminhada por dentro da muralha da cidadela dos corvos e encontram um circulo de teleportacao; Oferecem algumas de suas memorias e sao levados ao Shadowfell onde continuam na muralha ate encontrarem um quarto com explicacoes de mais dragonmarks, um diario do barao interim Guideon Loss. Ao decidirem continuar, antes de chegarem ao proximo circulo de teleportacao para continuarem a escalada da muralha no plano material. Se encontram com um Chorosine que acaba levando a vida de Vouli em troca de um deal, onde ele poderia ajudar os players caso levassem o Guideon para o Shadowfell. Voltando ao mundo material, continuam ate encontram 4 salas de canteiro de obra, guardadas por Raven Knights onde encontram Kaiser, novo integrante do grupo. Seguem viagem e encontram um exercito de knights da muralha aparentemente controlados pelos Alma mater, encontram uma saida de elevador prometendo leva-los ao hangar principal e:
- Uma sala com 4 estatuas da Raven Queen e um globo escuro que os players ainda nao sabem o que eh;
- Uma sala com mapas e catalogo de ligacoes por Astral Mirrors;
- Um disposal room com varios Godkin / Astralfolk;
- Conseguem atraves de forcar uma marca complexa de shadow/finding/passage liberar Slavi alegadamente um godkin confiante que os guia ate o elevador em busca de sair dali tambem.
  
- Layout do Hangar;
- Combate em partes / stealth ou sectional;
- Slavi;
- Guideon Loss pt 1;