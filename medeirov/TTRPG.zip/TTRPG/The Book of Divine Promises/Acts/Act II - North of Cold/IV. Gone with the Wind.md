A Mao de Auror, consegue escapar de Guideon depois de uma luta perigosa no hangar da Cidadela dos Corvos e segue norte para a tribo dos Godkin. Tendo salvo um da raca misteriosa, os aventureiros buscam mais informacoes de Slavi:
- Quem sao os godkin e qual o seu proposito: Uma raca espiritual que surge no plano astral e serve como vessels para substituicao dos Deuses. Quando um morre ou decide se aposentar, um godkin eh escolhido ou presenteado com a chance de se tornar o proximo herdeiro da godhood. Enquanto isso os elders mandam os godkin para diversos planos onde seus possiveis suditos vivem, em busca de entenderem melhor a vida deles e serem Deuses melhores;
- Eles utilizam as marcas para canalizar a Weave;
Os aventureiros vao parar possivelmente no Palacio de Neves em busca de abastecimento para o galeao voador que roubaram da cidadela. O Palacio funciona como um feudo, um castelo branco enorme no centro de uma mini-ilha de gelo eh cercao por fazendas e pequenas casas e construcoes. O Palacio na verdade esta vivo e consegue conseder contratos em troca de algo, com isso possui dominio sobre o Rei Shula. Devem conseguir os cartuchos com o Lord do feudo.
Nao sabem ainda que Guideon colocou um portal na parte inferior do galeao e pretende ataca-los de noite ou quando menos esperarem.
Caso consiguam prosseguir com mais combustivel, os aventureiros vao passar mais tempo que o esperado navegando na geleira ate a tribo dos godkin. Chegando la, podem adquirir algumas marcas e mais repostas sobre o que os Alma Mater querem e quando/onde podem impedi-los. Aqui eles tem a chance de transformar o Galeao deles num spelljammer.
Na sessao seguinte eles ainda estao no galeao de nome (”O corte mais fino”, desconhecido para os aventureiros - Maxim pode fornecer o nome ou eles podem investigar o navio mais a fundo em outras salas).
Guideon invade durante a madrugada o galeao, usando sua marca de teletransporte/rastreio. A marca comeca a se auto destruir possivelmente danificando o galeao no processo. 4 Cavaleiros (similares aos da prisao que vigiava Kaiser) juntamente com ele aparecem no deck e uma batalha se inicia quando Hedwyn tenta evitar que Guideon conclua a invocacao de Chorosine.
  
- Galeao crash no gelo, dependendo do estrago pode comecar a afundar na geleira;
- dunas de neve, sem sinal de vida;
- dependendo podem atrair scouts da tribo de godkin proximo;
Aqui estão quatro sugestões de magias únicas para o seu chefe feiticeiro/mago de D&D que enfrentará 5 jogadores de nível 6, levando em consideração que ele tem uma conexão com o Shadowfell:
1. **Umbral Grasp**
    - _School:_ Necromancy
    - This spell allows the boss to summon shadowy tendrils from the Shadowfell to restrain a target. It can target one or more players within a certain range and force them to make a Strength saving throw or become grappled by the shadowy tendrils for a duration, potentially leaving them vulnerable to subsequent attacks.
2. **Eclipse Ward**
    - _School:_ Abjuration
    - The boss can cast a protective ward that plunges the area into darkness, creating an eclipse-like effect. This spell grants the boss and nearby shadow minions advantage on saving throws and resistance against radiant damage. It also imposes disadvantage on ranged attacks made into or out of the affected area.
3. **Shadowmeld**
    - _School:_ Illusion
    - This spell allows the boss to merge with the shadows, becoming nearly invisible and intangible. While in this state, the boss gains a significant bonus to AC and Dexterity saving throws, making it difficult for players to successfully target or damage it. The boss might use this time to set up surprise attacks or cast spells from hiding.
4. **Umbral Rift**
    
    - _School:_ Conjuration
    - The boss can create a temporary rift to the Shadowfell, summoning shadowy creatures or minions to aid it in battle. These shadowy minions might have abilities like life-draining attacks or the ability to create zones of darkness that hinder the players' vision or movement.
    
    **Infernal Shadow Lance**
    
    - _School:_ Evocation
    - The boss conjures a blazing spear wreathed in shadows and flames, hurling it at a target. On a successful ranged spell attack, the target takes substantial necrotic and fire damage. Additionally, if the target fails a Constitution saving throw, they suffer ongoing damage at the start of each of their turns for a duration, taking additional fire and necrotic damage.

Entram na tribo do norte, encontram o templo de helm destruido e alertam uma galera ao encontra com o deus do cair da neve
alma mater perseguem eles e fogem :
