Depois de alistar Kawara na pit fight do Ninho do Corvo, buscando mais respeito e um pouco de notoriedade, a Mao de Auror teve uma experiencia de como se vive na Cidadela dos Corvos para o common folk. Kawara ganhou suas 2 primeiras lutas facilmente e teve de enfretar Ademo Garras-De-Corvo o campeao dos ultimos 1.5 anos
Em um empate fervorosoo rematch foi marcado para a noite seguinte, entretanto durante a luta Kawara percebe que Ademo tinha uma marca no ceu da sua boca e utilizou um tipo de habilidade que o permitiu se curar com uma mordida quase como um vampiro. Suspeitando que Ademo faz parte dos Alma Mater a Mao de Auror tenta conversar e extrair informacoes de Ademo sem muito sucesso. Na mesma noite indo para seu chale, Kawara encontra uma carta embaixo de uma vela pedindo um encontro nos becos atras da taverna. Ademo o espera no escuro e revela que algo de estranho nao esta certo na Cidadela e no Castelo do Corvos, reunioes estranhas e Kawara parece entender o que se passa.
Daqui, os aventureiros possivelmente vao escolher se infiltrar na reuniao de Guideon Loss no castelo dos corvos usando mascaras de Alma Mater. Devem navegar o castelo e passar pelos representantes das reunioes. Dentro do main ball room, uma comemoracao acontece Guideon faz announcementes e dentre eles menciona a morte de Sylvanus e seus dois aspectos. Finaliza sua fala com “Os planos superiores estao ao nosso alcance e nossa entrada nao sera mais barrada.”
Encontram um mascarado com o simbolo de Auril que um insight dificil revela ser Solas, barao interim de Palewind atualmente e uma pedra no sapato dos aventureiros. Ao se infiltrar no andar do barao e investigar seu quarto encontram a passagem secreta e uma sala em construcao por servos da soulmancy e uma penseira semi-completa, mais journals detalham um plano meior e uma cadeia de comando.
  
Raven Queens Duty
ranged mist protection 2x day
quick draw fight start
mark of the raven
  
A Mao de Auror se encontra num dos andares do castelo dos corvos, tendo derrotado Muraki eles buscam uma forma de sair do castelo despercebidos e quem sabe com o corpo do inimigo.
Do quarto do barao eles podem encontrar uma passagem secreta para o hangar ;
Eles podem tentar ir ate a ponte para tentar passar ate o hangar naturalmente; (Personagem do gabriel pode saber onde esta a chave)
A mao de Auror volta da infiltracao no castelo dos corvos.
O baile de mascaras provou ser extremamente util em termos de informacao, os aventureiros aprenderam que:
- Existencia de uma tribo conhecida como Godkin ou Astralkin
- Os alma matter estao espalhados pelo Imperio e tentam assumir posicoes de influencia para prosseguir com seus planos
- Muraki foi “derrotado” mas ainda esta vivo
- Existem Mage Seekers na cidadela
- Receberam um diario que sera revelado como um diario astral, serve para se comunicar com alguem que esta no plano astral.
  
Postados na carruagem dentro da estalagem Ninho dos Corvos, os aventureiros discutem os proximos passos.