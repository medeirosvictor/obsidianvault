
Observando o livro de Ratan once again vemos que o passado esta mais revelado, mostrando que a tribo do norte da qual ele fazia parte foi abordada por alma maters em busca dos godkin do norte. Ratan ja mais velho foi um dos que achou o acordo postado por Guideon e Solas um bom profit para sua tribo. Eles apontaram onde no norte poderiam encontrar mais dos seres estranhos que romeavam os bosques e voltavam para o endless ice. Capturaram alguns, dentre eles, Slavi.
No final do encontro seu potencial havia sido reconhecido e Guideon o faz um convite ao Palacio dos Corvos, com uma enigmatica frase ”by then I will be Baron and I shall give you the answers you seek”. Entretanto depois de algum periodo de jornadas e seu acidente na blizzard, Ratan parte em direcao mais ao sul. Ao tentar entrar em contato com Guideon e Solas este apelava para suas crencas, dizendo que a verdadeira neutralidade era uma unica forca em comando sendo neutral, os whims de Deuses e seus assistentes e bencaos e curses impediam as almas puras do mundo material e as corrompiam com promessas e sedes de vinganca um contra os outros, apenas Elyrian poderia trazer a neutralidade completa para o panteao. Ainda que se concordando ou nao, Ratan nao via uma forma correta de dizer nao para aqueles que estavam ali presentes, e se viu fazendo parte de um ritual que incidentalmente apagou parte de suas memorias.
  
  
No fundo da torre um astral dragon esta emprisioned e apenas ativando a tier 4 da mark of death podem tirar ele do slumber, cancelando o scry de Nimue.
  
Fighting Nimue
Nimue pode apagar passagens dos livros de alguns players, removendo spell, spell slots, memoria sobre o efeito de items e mais. Os players devem resistir com um Con/Wis/Int saving throw.
Spellcaster forte.
Penumbra, the adult dragon
  
  
Nimues Storybook
Writer’s Daggers, requires 1 writing feather as non consumable component (Mateiral only)
lvl 4, no concentration required, 100ft range, duration 1min
Summon 4 or 1d12 feathers, they hover around your body and you can use a bonus action to trigger 1dX daggers to do 3d4 each as magical ranged attacks. You can only have 12 feathers active. The feathers do either piercing or slashing damage  
You can use your action to summon extra 2d4 feathers as long as you still have feathers active  
Increase the spell slot to add 1d4 damage and 1 extra minimal feathers (and 1 more to the maximum limit)
# Far Step
[XGEp155](https://5e.tools/book.html#xge,page:155)
---
5th-level conjuration
---
Casting Time:
1 bonus action
---
Range:
Self
---
Components:
V
---
Duration:
Concentration, up to 1 minute
---
---
You teleport up to 60 feet to an unoccupied space you can see. On each of your turns before the spell ends, you can use a bonus action to teleport in this way again.
---