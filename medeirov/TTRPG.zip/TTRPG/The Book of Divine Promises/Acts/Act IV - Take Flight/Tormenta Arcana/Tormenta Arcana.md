![[ArcaneTorment.png|ArcaneTorment.png]]
  
![[image 2.png|image 2.png]]
![[Untitled 1 2.png|Untitled 1 2.png]]
![[Tirano.png|Tirano.png]]
  
Treason for Life
Horizon dying light
![[image 1.png]]
- Players andam por halls depicting traidores e historias de traicao;
- No ultimo quarto encontram Iliarosa, um godkin amigo-irmao de Elirian Lider Supremo dos Alma Mater; Iliarosa encontra-se depressivo e acorrentado preso pelas circunstancias dos halls dos traidores. Apenas mentirosos andam ali e conversar com Iliarosa pode ser nao confrontational mas ao tentar solta-lo este vai testa-los em combate.
  
[https://www.youtube.com/watch?v=2x11dmoTwYU](https://www.youtube.com/watch?v=2x11dmoTwYU)
![[Illiarosa3.png|Illiarosa3.png]]
![[Illiarosa2.png|Illiarosa2.png]]
![[Illiarosa.png]]
**Nascimento de Elirian e Iliarosa:** Elirian e Iliarosa surgiram juntos da pool astral, suas almas entrelaçadas desde o início. Os Godkin, consultando os Dragões Astrólogos, frequentemente viajam para lugares de eventos cósmicos significativos ou reinos dos sonhos para selecionar almas prontas para serem forjadas no que os Godkin antigos acreditam ser uma raça superior. Um aprendiz, seguindo um mestre, aprende a arte delicada de forjar almas e questiona se Elirian e Iliarosa estão prontos para se tornarem Godkin. O mestre nega, mas o aprendiz acredita que o processo poderia ser aprimorado. Em vez de esperar por um mínimo de honra, qualquer Godkin deveria poder crescer em seu próprio tempo, o que os tornaria mais fortes. O mestre argumenta que, embora isso possa ser verdade, também poderia levar a mais caos do que ordem. O aprendiz, em sua ânsia, extrai e forja erroneamente aqueles que se tornariam Elirian e Iliarosa.
**Primeiras Dificuldades e Treinamento:** Inseparáveis desde o nascimento, Elirian e Iliarosa lutaram com o primeiro passo da formação Godkin: recompor-se em matéria usando pura força de vontade para viver. O aprendiz, agora seu mestre, os guiou através de inúmeras reencarnações como seres empobrecidos em vários planos. Elirian tornou-se obcecado com o plano material, sua empatia pelos mortais crescendo a cada vida. Sua iluminação espiritual revelou-lhe que aqueles no plano material adoravam apenas um fragmento do grande composto do universo da vida.
**Divergência Filosófica:** A obsessão de Elirian com o plano material e sua empatia pelos mortais o levaram a questionar as práticas dos Godkin. Ele via a seleção de almas como um processo falho que desprezava o potencial de muitos seres. Iliarosa, por outro lado, permanecia mais alinhado com as crenças tradicionais dos Godkin, valorizando a ordem e a estrutura que suas práticas traziam ao cosmos.
**O Ponto de Virada:** A crescente desilusão de Elirian com as práticas dos Godkin e o panteão dos deuses atingiu um ponto crítico. Ele acreditava que os deuses eram desdenhosos e indignos de adoração, e que o verdadeiro equilíbrio do universo estava nas mãos dos Godkin, Dragões Astrais e as forças primordiais do Caos e da Ordem. O desejo de Elirian de injetar todos os seres materiais com suas memórias, revelando a natureza desdenhosa do panteão, tornou-se sua força motriz. Ele buscava instigar o mundo a orar aos Godkin, Dragões Astrais e às forças primordiais em vez dos deuses habituais.
**O Pacto e a Traição:** Usando marcas de dragão de equilíbrio, Elirian e Iliarosa juraram um voto vinculativo de nunca se machucarem, fortalecendo seu vínculo fraternal. No entanto, esse voto tornou-se a ruína de Iliarosa quando ele viu o caminho que Elirian escolheu. Incapaz de agir contra seu irmão, Iliarosa foi impotente enquanto os planos de Elirian se desenrolavam.
**Descida de Elirian à Escuridão:** A transformação de Elirian em vilão foi impulsionada por seu desejo de derrubar o panteão dos deuses e assumir o controle dos Dragões Astrais. Ele visava impedir os Godkin de selecionar almas e remodelar o cosmos de acordo com sua visão de equilíbrio. Seus métodos tornaram-se cada vez mais implacáveis, e suas intenções outrora nobres foram distorcidas por sua obsessão com poder e controle.
Iliarosa pergunta a Elyrian - Voce quer destruir tudo? Mas o que surgira depois??  
Elyrian: Uma casa esta em chamas, haviaa gente la dentro, alguem grita pela janela “Como esta o tempo ai fora? Chovendo? Ventando?” …. Voce se afastaria Iliarosa, nobre porem lhe falta o passo que agora nos separa… Vou me livrar dos arsenicos que a incediaram, dos que podem apagar as chamas e nao o fazem. O silencio nao sera um misterio a ser decifrado anymore, sem indiferenca is how we will live.  
  
Can you remember who you were before the Godkin told you who to be?
  
![[image 2 2.png|image 2 2.png]]
![[GodkinArcaneTormentBazzaar.png]]
[https://www.youtube.com/watch?v=2x11dmoTwYU](https://www.youtube.com/watch?v=2x11dmoTwYU)
[https://www.youtube.com/watch?v=4aaOMfVEomU](https://www.youtube.com/watch?v=4aaOMfVEomU)
  
[low of solipsism](https://www.youtube.com/watch?v=81D8CCguW4g)
![[IMG_4073.png]]
  
Depois de recuperar os poderes de Elir, elvis o arquiteto vai indicar que agora ele tem mais detalhes sobre as mentiras que ele vai contar no futuro:
- Em nao mais que 3 instancias ele ira mentir por cerca de 30min, assunto e momento undisclosed
Aqui os players podem ir para varias salas
- saindo do cemiterio podem seguir descendo escadas of bonding;
Portas vao se abrindo para as seguintes:
- Room of the beast:
**Inscrição na Entrada:**
"He who makes a beast out of himself
Gets rid of the pain of being a man"
No centro da sala uma criatura imensa cercada de outros seres que imitam seus movimentos; Matar a criatura ou escapar da sala, uma porta aberta apos o salao; encontram um pingente que esta sendo clutched por um esqueleto de pedra que esta preso dentro da boca da estatua da criatura da sala anterior morto, 1 lvl a todos caso toquem no pingente;
  
- Room treasures 1: Guardado por imps que parecem venerar um Imp maior que segura um item magico da lista e guarda outro item magico. sao cerca de 6 imps no total
- Room of leveling: entram em um quarto escuro e precisam tatear o way out, lights might work but beasts. em um dos caminhos they will find 3 simulacros de um mago que tentam se destruir mas estao cursed a sempre achar o camnho certo;
- Room of leveling: The elf who saw seconds, 7 seconds after making a decision he knows if it was the best he could have taken or if there was another one better; and everytime he is wrong his body burns to a nova and incinerates everything around him;
  



Illiarosa fight

Roll for CON/WIS save to see if they can read the fine print
They will use the subjects of traitors as fall guys for the contracts
3 Legendary Resistance + 1 for each subbordinado sacrificado;

First round  
2 stone walls and one sunbeam;

Make the subordinados hold the concentration for his spells - Call Lightning

illiarosa pode oferecer contratos por spell slots, action surges, para os aliados em troca de repetir suas acoes;

illiarosa pode forfeit seu turno para agir 2x no turno seguinte;

illiarosa oferece um contrato para leva-los para fora da tormenta ao atingir o half-way point, aparecendo em um empty bazaar, com uma cratera e ruinas; este parece vagar fora do ciclo de navegacao e parece ir em direcao a tormenta;

illiarosa ao atingir roughly metade da vida (a adaptar pelo dmg output da party) abscond de poder usar magias e se torna uma menace physica; Tensers transformation spell;

illiarosa pode emitir um contrato para parar de andar ou correr, fine print revela que agora ele voa e plana;

illiarosa pode oferecer trocar um membro dele (bait using description of how he seems to cast his spells)



trade casting spells with phsyical prowess
trade walking with flying trick contract
cancel ilusion to make trees disappear
make astral dragon of treason direct one of the spells or attacks of one of them towards each other
trade limbs for limbs

![[Pasted image 20240927232116.png]]