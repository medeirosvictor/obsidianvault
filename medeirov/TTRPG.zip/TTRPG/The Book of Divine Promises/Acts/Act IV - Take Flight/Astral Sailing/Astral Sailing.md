![[Untitled 3.png|Untitled 3.png]]
O gamba o guaxinim e o gato mexicanos
  
Astral Bazzaar 7B8M12K - O Pergolago
estabelecimentos—
side quests?—
  
Jaz noir theme when sailing
  
The only weird thing is that your physical body doesn't experience the physical effects of time while you're there. For those three days, you don't age, don't heal naturally, don't grow hungry or thirsty, etc.
  
## Tormenta Arcana
  
  
[[O Pergolago - 7B8M12K]]