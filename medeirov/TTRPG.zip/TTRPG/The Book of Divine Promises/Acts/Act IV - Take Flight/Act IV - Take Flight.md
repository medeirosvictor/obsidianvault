Em Calimport -
Kawara e Prego conseguem ganhar as preliminatorias da arena e podem agora competir em niveis mais elevados
  
As familias estao investigando Mathias Lenore; Um grupo de espioes vai entrar na casa de Lenore para investigar atitudes suspeitas e itens estranhos; Dentro da casa eles vao encontrar a lista de assassinatos feitos pelos Rattle Snakes e um plano de exterminar as familias. Lenore possui um tunel que leva ate o esconderijo dos rattle snakes. Luta contra around 25 low level thugs, podem perceber a emboscada antes e preparar acoes pra garantir vitoria rapida. Se demorarem demais, os membros das outras familias vao comecar a cair e Nimbus sera a proxima vitima, eles encontram uma carta, o estate dela vai estar sendo atacado.
  
Os mage seekers podem ser triggered para ajudar a com bater Kemps e Solas. Aqui os players precisam conversar mais com os mage seekers pra tirar Kemps e Solas da cidade, Solas tinha um simulacrum que foi derrotado. Kemps nao possui muitas habilidades, possui apenas dragonmarks decentes de charming e social interactions. O senador de armas recebe noticia de que sua familia em uma viagem de volta de ferias aparentemente esta em perigo nos outskirts de calimsham e ele vai ate la para encontra-los enquanto Kemps assume a posicao do senador temporariamente.
  
Os nobunaga se investigados em seu galeao vao revelar a localizacao de Akira no plano astral. De forma geral, os nobunaga nao deveriam ligar para clientelas fixas ou agendas, alguns do comando estao buscando saber por que eles estao sendo escravos do dinheiro dessa maneira.
  
O aspecto de Heliod esta em Surya que vai grow stronger a cada dia, Surya agora pode se transformar em um dragao caso ativem sua mark of death lmao  
  
Nimue os ajudou a derrotar Darius mas este sobreviveu e vai cacar a mao de auror em breve, assim que sairem de Calimport eles vao ser hunted down  
  
Proximos passos dos Alma matter?
  
Futuro de Calimport, rattle snakes e senado + imperatriz align
  
Main Goals for the party
- Cancel dragon marks on alma matter
- Go to the Forest of the Gods
- ??? ask them
[[Em Calimport]]
[[The Storyteller's Tower]]
[[Astral Sailing]]
[[Tormenta Arcana]]